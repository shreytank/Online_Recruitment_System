/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package online_recruitment_system;

import javax.swing.JPanel;

/**
 *
 * @author asus
 */
public interface Focus {
    void setFocus(JPanel pane);
    void resetFocus(JPanel pane);
    
}
